#!/bin/bash
echo "Launching PilotHouse POS..."
npx electron .
