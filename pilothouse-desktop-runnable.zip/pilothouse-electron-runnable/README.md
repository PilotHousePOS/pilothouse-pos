# PilotHouse POS — Desktop App (Runnable Package)

## Requirements
- Node.js 18 or newer → https://nodejs.org

## How to run

### Windows
Double-click **run-windows.bat**  
*or* open a terminal in this folder and run: `npx electron .`

### macOS / Linux
Open Terminal, `cd` into this folder, then:
```bash
chmod +x run-mac.sh
./run-mac.sh
```
*or*: `npx electron .`

## What it connects to
The app opens your live PilotHouse server at **https://pilothouse.replit.app**  
Log in with your normal credentials — everything works identically to the browser.

## To build a real installer (.exe / .dmg)
From the full project folder on your machine:
```bash
npm install
npm run build:electron
```
Output: `dist/installers/`
