@echo off
echo Launching PilotHouse POS...
npx electron .
if %ERRORLEVEL% NEQ 0 (
  echo.
  echo ERROR: Could not launch. Make sure Node.js is installed:
  echo https://nodejs.org
  pause
)
